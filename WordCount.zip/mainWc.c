#include "wc.h"

int main(int argc,char* argv[])
{
	FILE* f=NULL;
	if(argc<=2) wordcount(f,argv);
	else wordarg(f,argv);

return 0;
}
