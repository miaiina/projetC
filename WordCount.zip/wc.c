#include "wc.h"

void wordcount(FILE* f,char* argv[]){
	char* n=NULL;
	n=(char*)malloc(1000000*sizeof(char));
	f=fopen(argv[1],"r");
	int g=0;
	for(int i=0; i<1000000; i++){
		fscanf(f,"%c",&n[i]);
	}
	
	for(int i=0; i<1000000; i++){
		if(n[i]=='\n')
			g++;
		}
		printf(" %d ",g);
	
	char* r=NULL;
	r=(char*)malloc(1000000*sizeof(char));
	int h=0;
	rewind(f);
	while(!feof(f)){
		fscanf(f,"%s",r);
		h++;
	}
	printf(" %d ",h-1);
	
	int t=0;
	for(int i=0; i<strlen(n); i++){
		t++;
	}
	printf(" %d ",t);
	printf(" %s",argv[1]);
	printf("\n");
	fclose(f);
}

void wordarg(FILE* f,char* argv[]){
	char* n=NULL;
	n=(char*)malloc(1000000*sizeof(char));
	f=fopen(argv[2],"r");
	int g=0;
	for(int i=0; i<1000000; i++){
		fscanf(f,"%c",&n[i]);
	}
	
	if(strcmp(argv[1], "-l")==0){
		for(int i=0; i<1000000; i++){
		if(n[i]=='\n')
			g++;
		}
		printf(" %d ",g);
	}
	
	if(strcmp(argv[1],"-c")==0){
		char* r=NULL;
		r=(char*)malloc(1000000*sizeof(char));
		int h=0;
		rewind(f);
		while(!feof(f)){
		fscanf(f,"%s",r);
		h++;
	}
		printf(" %d ",h-1);
	}
	
	if(strcmp(argv[1],"-m")==0){
		int t=0;
		for(int i=0; i<strlen(n); i++){
		t++;
	}
		printf(" %d ",t);
}
	printf(" %s",argv[2]);
	printf("\n");
	fclose(f);
	}
	
	
