#ifndef WC_C
#define WC_C

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void wordcount(FILE* f,char* argv[]);

void wordarg(FILE* f,char* argv[]);

#endif
