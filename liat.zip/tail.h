#ifndef TAIL_H
#define TAIL_H

#include <stdio.h>
#include <stdlib.h>

char* allocation();

void file(FILE*(f),char* a,char* argv[]);
#endif
