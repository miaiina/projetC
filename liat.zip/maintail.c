#include "tail.h"

int main(int argc,char* argv[])
{
	FILE* f=NULL;
	char* a=NULL;
	a=allocation();
	file(f,a,argv);
	
return 0;
}
