#include "tail.h"

char* allocation()
{
	char* G=NULL;
	G=(char*)malloc(1000*sizeof(char));
	return G;
	}
	
void file(FILE*f,char* a,char* argv[])
{
	int s=0,g=0,m=0;
	f=fopen(argv[2],"r");
	for(int i=0; i<1000; i++)
	{
		fscanf(f,"%c",&a[i]);
	}
	for(int h=0; h<1000; h++)
	{
		if(a[h]=='\n') 
		s++;
		
	}
	for(m=0; m<1000; m++)
	{
		if(a[m]=='\n')
		{
			g++;
		}
		if(s-g==atoi(argv[1]))
		{
			break;
		}
	}
	for(int j=m; j<1000; j++)
	{
		printf("%c",a[j]);
	}	
	
	fclose(f);
}

